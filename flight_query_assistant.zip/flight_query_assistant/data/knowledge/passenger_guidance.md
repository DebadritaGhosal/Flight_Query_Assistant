# General Passenger Guidance

## Check-in and airport arrival
Passengers should verify the operating airline's check-in deadline before travel. Airport arrival time depends on whether the journey is domestic or international, the airport, security procedures, baggage drop requirements, and the airline. Online check-in does not always remove the need to visit a counter, particularly when documents must be verified or checked baggage must be accepted.

## Cabin baggage and restricted items
Cabin baggage dimensions and weight limits vary by airline, route, cabin, and fare. Passengers should check the operating airline's current allowance. Spare lithium batteries and power banks are generally carried in cabin baggage rather than checked baggage, with terminals protected against short circuit. Capacity restrictions and airline approval requirements may apply. Security authorities and airlines may impose additional restrictions, so passengers should confirm the current rule before travel.

## Checked baggage problems
A passenger whose checked baggage is missing, delayed, or damaged should report it at the airport baggage service desk before leaving the arrivals area whenever possible. The passenger should keep the baggage tag, boarding pass, property irregularity report, photographs, receipts for essential purchases, and correspondence. Reimbursement and claim deadlines vary by carrier and jurisdiction.

## Delays, cancellations, and missed connections
During a delay or cancellation, passengers should monitor official airline and airport channels, preserve notices and receipts, and contact the operating airline for rebooking or refund options. Assistance, compensation, and refund rights depend on the operating airline, route, fare conditions, reason for disruption, and applicable law. For a missed connection on a single protected itinerary, the airline may provide rebooking, but the exact obligation varies. Separate tickets may not receive the same protection.

## Refunds and rebooking
Refund eligibility and processing time depend on the ticket conditions, the reason for cancellation, the payment method, and local law. Passengers should use official airline or authorized travel-agent channels and keep the request reference number. The assistant must not present one airline's refund rule as universal.

## Travel documents
Passengers are responsible for carrying valid documents required by the origin, transit, and destination authorities. Requirements can include a passport, visa, identity document, health documentation, onward-travel evidence, or permits. Rules change and should be verified through official government, airport, and airline sources before departure.

## Passenger assistance
Passengers needing mobility, medical, sensory, or other assistance should contact the airline or airport early. Advance notice requirements and available services vary. Essential medication and supporting documents should be packed according to security and carrier requirements.
