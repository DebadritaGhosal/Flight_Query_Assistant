from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flight_assistant.config import get_settings
from flight_assistant.services.assistant import FlightQueryAssistant
from flight_assistant.services.rag import RAGService


st.set_page_config(page_title="Flight Query Assistant", page_icon="✈️", layout="wide")
st.title("✈️ Flight Query Assistant")
st.caption("Live flight tracking through AeroDataBox and passenger guidance through a local RAG knowledge base.")

settings = get_settings()

with st.sidebar:
    st.subheader("Configuration")
    st.write(f"**LLM:** `{settings.openrouter_model}`")
    st.write(f"**Flight mode:** {'Mock data' if settings.use_mock_flight_api else 'AeroDataBox live API'}")
    warnings = settings.validate_runtime()
    for warning in warnings:
        st.warning(warning)
    if st.button("Rebuild knowledge index"):
        try:
            count = RAGService(settings).ingest_directory(reset=True)
            st.success(f"Indexed {count} chunks.")
        except Exception as exc:
            st.error(str(exc))
    st.divider()
    st.markdown("**Try:**")
    st.code("Is AI302 delayed today?", language=None)
    st.code("Can I carry a power bank in cabin baggage?", language=None)

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

query = st.chat_input("Ask about a flight or passenger guidance")
if query:
    st.session_state.messages.append({"role": "user", "content": query})
    with st.chat_message("user"):
        st.markdown(query)

    with st.chat_message("assistant"):
        try:
            assistant = FlightQueryAssistant(settings)
            result = assistant.ask(query, st.session_state.messages[:-1])
            st.markdown(result.answer)
            with st.expander("Routing details"):
                st.json(result.route.model_dump(mode="json") if result.route else {})
            answer = result.answer
        except Exception as exc:
            answer = f"Configuration or runtime error: {exc}"
            st.error(answer)
    st.session_state.messages.append({"role": "assistant", "content": answer})
