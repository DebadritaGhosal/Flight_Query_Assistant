# Flight Query Assistant

A two-route LangGraph application:

1. **Flight Tracking** — retrieves date-specific flight status from AeroDataBox.
2. **Passenger Knowledge** — retrieves relevant document chunks from Chroma and generates a grounded answer through OpenRouter.

There is deliberately no third combined API-plus-RAG route in this version.

## Architecture

```text
User query
   |
   v
OpenRouter intent router
   |-----------------------------|
   v                             v
Flight Tracking            Passenger Knowledge
   |                             |
AeroDataBox                 Local embeddings
   |                        + Chroma retrieval
Normalized flight data           |
   |                        OpenRouter answer
   |-----------------------------|
                 v
              Response
```

## Technology choices

- **LangGraph:** explicit state and conditional routing.
- **OpenRouter:** one OpenAI-compatible client; the model slug is configured through `.env`, so the application code is model-agnostic.
- **AeroDataBox:** direct flight-number and date lookup.
- **Chroma:** local persistent vector database.
- **Sentence Transformers:** local embeddings, avoiding a separate embedding API key.
- **Streamlit:** demonstration interface.

## Project structure

```text
app/streamlit_app.py               Streamlit interface
flight_assistant/clients/          OpenRouter, AeroDataBox and mock clients
flight_assistant/graph/            LangGraph construction
flight_assistant/nodes/            Router, flight, RAG and clarification nodes
flight_assistant/services/         Routing, RAG, formatting and app service
flight_assistant/models/           Typed state and Pydantic schemas
scripts/ingest.py                  Build the local knowledge index
scripts/test_aerodatabox.py        Test a live flight lookup directly
scripts/run_cli.py                 Command-line interface
data/knowledge/                    Add PDF, TXT or Markdown guidance here
tests/                             Offline unit tests
```

## Setup on Windows PowerShell

```powershell
cd flight_query_assistant
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Open `.env` and set at least:

```env
OPENROUTER_API_KEY=your_key
OPENROUTER_MODEL=your_selected_model_slug
USE_MOCK_FLIGHT_API=true
```

The model is never hardcoded in graph or node code. Changing `OPENROUTER_MODEL` changes the model used for routing and RAG generation.

## Build the RAG index

The repository contains one general passenger-guidance Markdown document. Add your own `.pdf`, `.txt`, or `.md` files to `data/knowledge/`, then run:

```powershell
python scripts/ingest.py --reset
```

The first ingestion downloads the local sentence-transformer model and may take longer than later runs.

## Run the app

```powershell
streamlit run app/streamlit_app.py
```

Example questions:

```text
Is AI302 delayed today?
Where is flight 6E204 right now?
Can I carry a power bank in cabin baggage?
What should I keep if my checked baggage is delayed?
```

## Enable the live AeroDataBox API

Create an AeroDataBox direct API subscription and update `.env`:

```env
AERODATABOX_API_KEY=your_key
USE_MOCK_FLIGHT_API=false
```

Test the provider independently before using the UI:

```powershell
python scripts/test_aerodatabox.py AI302 2026-07-29
```

The client calls the single-day flight-status endpoint by flight number and local date. It requests location data, normalizes partial results, and never invents missing gate, terminal, or position fields.

## Run offline tests

```powershell
pytest -q
```

The tests do not call OpenRouter or AeroDataBox.

## Important limitations

- Flight data can be partial or unavailable depending on coverage.
- Exact passenger rights, baggage allowances, refunds, and compensation vary by airline, fare, route, and law.
- The included guidance is only demonstration content. Replace it with authoritative documents before presenting the system as a real advisory tool.
- Flight number plus date is the reliable lookup pair. When the date is omitted, the router uses the current date.
