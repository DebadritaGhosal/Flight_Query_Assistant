from __future__ import annotations

from flight_assistant.config import Settings
from flight_assistant.graph.builder import build_graph
from flight_assistant.models.schemas import AssistantResponse


class FlightQueryAssistant:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.graph = build_graph(settings)

    def ask(
        self,
        query: str,
        conversation_history: list[dict[str, str]] | None = None,
    ) -> AssistantResponse:
        if not query.strip():
            raise ValueError("Query cannot be empty.")
        result = self.graph.invoke(
            {
                "user_query": query.strip(),
                "conversation_history": conversation_history or [],
            }
        )
        return AssistantResponse(
            answer=result.get("final_answer", "No answer was generated."),
            intent=result.get("route").intent if result.get("route") else None,
            route=result.get("route"),
            flight=result.get("flight_result"),
            sources=result.get("retrieved_chunks", []),
            debug={"error": result.get("error")} if result.get("error") else {},
        )
