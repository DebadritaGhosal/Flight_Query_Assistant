from __future__ import annotations

from datetime import datetime

from flight_assistant.models.schemas import FlightStatusResult


def _fmt_time(value: datetime | None) -> str:
    if not value:
        return "Not available"
    return value.strftime("%d %b %Y, %H:%M %Z").strip()


def format_flight_response(flight: FlightStatusResult, query: str) -> str:
    dep = flight.departure
    arr = flight.arrival
    lines = [
        f"**{flight.flight_number} — {flight.status.replace('_', ' ').title()}**",
        "",
        f"- **Route:** {dep.city or dep.airport_name or 'Unknown'} ({dep.airport_iata or '—'}) → "
        f"{arr.city or arr.airport_name or 'Unknown'} ({arr.airport_iata or '—'})",
        f"- **Scheduled departure:** {_fmt_time(dep.scheduled_time_local or dep.scheduled_time_utc)}",
        f"- **Latest departure:** {_fmt_time(dep.actual_time_local or dep.revised_time_local or dep.actual_time_utc or dep.revised_time_utc)}",
        f"- **Scheduled arrival:** {_fmt_time(arr.scheduled_time_local or arr.scheduled_time_utc)}",
        f"- **Latest arrival:** {_fmt_time(arr.actual_time_local or arr.revised_time_local or arr.actual_time_utc or arr.revised_time_utc)}",
        f"- **Departure terminal / gate:** {dep.terminal or 'Not available'} / {dep.gate or 'Not available'}",
        f"- **Arrival terminal / gate:** {arr.terminal or 'Not available'} / {arr.gate or 'Not available'}",
    ]
    if flight.departure_delay_minutes is not None:
        lines.append(f"- **Departure delay:** {flight.departure_delay_minutes} minutes")
    if flight.arrival_delay_minutes is not None:
        lines.append(f"- **Arrival delay:** {flight.arrival_delay_minutes} minutes")
    if flight.position:
        lines.append(
            f"- **Last known position:** {flight.position.latitude:.4f}, "
            f"{flight.position.longitude:.4f}"
        )
        if flight.position.altitude_meters is not None:
            lines.append(f"- **Altitude:** {flight.position.altitude_meters:,.0f} metres")
    if flight.aircraft_model or flight.aircraft_registration:
        lines.append(
            f"- **Aircraft:** {flight.aircraft_model or 'Unknown model'}"
            f" ({flight.aircraft_registration or 'registration unavailable'})"
        )
    lines.extend(["", f"*Data source: {flight.data_source}.*"])
    if flight.warnings:
        lines.extend(["", "**Data notes:**"] + [f"- {item}" for item in flight.warnings])
    return "\n".join(lines)
