from __future__ import annotations

from datetime import date

from flight_assistant.clients.openrouter import OpenRouterClient
from flight_assistant.models.schemas import QueryIntent, RouteDecision


ROUTER_SYSTEM_PROMPT = """You classify queries for a Flight Query Assistant.
There are only two business routes:
1. flight_tracking: live or date-specific facts about a particular flight, including status, delay, departure, arrival, terminal, gate, aircraft, or location.
2. passenger_knowledge: general passenger guidance from documents, including baggage, check-in, restricted items, travel documents, refunds, cancellations, disruptions, and passenger rights.

Rules:
- A flight-tracking query normally needs a flight number. Extract compact uppercase flight numbers such as AI302 or 6E204.
- Resolve relative dates using the supplied current date.
- If flight tracking is requested but no flight number is provided, return clarification.
- Do not create a combined route.
- Keep reasoning_summary to one short sentence.
"""


class QueryRouter:
    def __init__(self, llm: OpenRouterClient):
        self.llm = llm

    def route(self, query: str, current_date: date) -> RouteDecision:
        prompt = f"Current date: {current_date.isoformat()}\nUser query: {query}"
        decision = self.llm.complete_json(
            system_prompt=ROUTER_SYSTEM_PROMPT,
            user_prompt=prompt,
            schema=RouteDecision,
        )
        if decision.intent == QueryIntent.FLIGHT_TRACKING and not decision.flight_number:
            return RouteDecision(
                intent=QueryIntent.CLARIFICATION,
                sub_intent=decision.sub_intent,
                needs_clarification=True,
                clarification_question="Please provide the flight number, for example AI302 or 6E204.",
                reasoning_summary="A live flight lookup requires a flight number.",
            )
        if decision.intent == QueryIntent.FLIGHT_TRACKING and not decision.flight_date:
            decision.flight_date = current_date
        return decision
