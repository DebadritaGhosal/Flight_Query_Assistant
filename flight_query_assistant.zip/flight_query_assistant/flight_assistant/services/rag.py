from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Iterable

import chromadb
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer

from flight_assistant.config import Settings
from flight_assistant.models.schemas import RetrievedChunk


class RAGService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.settings.chroma_directory.mkdir(parents=True, exist_ok=True)
        self.client = chromadb.PersistentClient(path=str(settings.chroma_directory))
        self.collection = self.client.get_or_create_collection(
            name="passenger_guidance",
            metadata={"hnsw:space": "cosine"},
        )
        self.embedding_model = SentenceTransformer(settings.embedding_model)

    def ingest_directory(self, reset: bool = False) -> int:
        if reset:
            try:
                self.client.delete_collection("passenger_guidance")
            except Exception:
                pass
            self.collection = self.client.get_or_create_collection(
                name="passenger_guidance", metadata={"hnsw:space": "cosine"}
            )

        documents: list[str] = []
        metadatas: list[dict] = []
        ids: list[str] = []
        for path in sorted(self.settings.knowledge_directory.rglob("*")):
            if path.suffix.lower() not in {".pdf", ".txt", ".md"}:
                continue
            for page, text in self._read_document(path):
                for index, chunk in enumerate(self._chunk(text)):
                    source = str(path.relative_to(self.settings.knowledge_directory))
                    chunk_id = hashlib.sha256(
                        f"{source}:{page}:{index}:{chunk}".encode("utf-8")
                    ).hexdigest()
                    documents.append(chunk)
                    metadatas.append({"source": source, "page": page or 0})
                    ids.append(chunk_id)

        if not documents:
            return 0
        embeddings = self.embedding_model.encode(
            documents, normalize_embeddings=True, show_progress_bar=False
        ).tolist()
        self.collection.upsert(
            ids=ids,
            documents=documents,
            metadatas=metadatas,
            embeddings=embeddings,
        )
        return len(documents)

    def retrieve(self, query: str) -> list[RetrievedChunk]:
        if self.collection.count() == 0:
            return []
        vector = self.embedding_model.encode(
            [query], normalize_embeddings=True, show_progress_bar=False
        ).tolist()[0]
        result = self.collection.query(
            query_embeddings=[vector],
            n_results=min(self.settings.rag_top_k, self.collection.count()),
            include=["documents", "metadatas", "distances"],
        )
        chunks: list[RetrievedChunk] = []
        for text, metadata, distance in zip(
            result.get("documents", [[]])[0],
            result.get("metadatas", [[]])[0],
            result.get("distances", [[]])[0],
        ):
            chunks.append(
                RetrievedChunk(
                    text=text,
                    source=str(metadata.get("source", "unknown")),
                    page=int(metadata.get("page") or 0) or None,
                    score=1.0 - float(distance),
                )
            )
        return chunks

    def _chunk(self, text: str) -> Iterable[str]:
        cleaned = " ".join(text.split())
        if not cleaned:
            return []
        size = self.settings.chunk_size
        overlap = min(self.settings.chunk_overlap, size - 1)
        chunks: list[str] = []
        start = 0
        while start < len(cleaned):
            end = min(len(cleaned), start + size)
            if end < len(cleaned):
                boundary = cleaned.rfind(" ", start, end)
                if boundary > start + size // 2:
                    end = boundary
            chunks.append(cleaned[start:end].strip())
            if end >= len(cleaned):
                break
            start = end - overlap
        return chunks

    @staticmethod
    def _read_document(path: Path) -> list[tuple[int | None, str]]:
        if path.suffix.lower() == ".pdf":
            reader = PdfReader(str(path))
            return [(i + 1, page.extract_text() or "") for i, page in enumerate(reader.pages)]
        return [(None, path.read_text(encoding="utf-8", errors="ignore"))]
