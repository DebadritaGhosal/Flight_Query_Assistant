from __future__ import annotations

from typing import TypedDict

from flight_assistant.models.schemas import FlightStatusResult, RetrievedChunk, RouteDecision


class AssistantState(TypedDict, total=False):
    user_query: str
    conversation_history: list[dict[str, str]]
    route: RouteDecision
    flight_result: FlightStatusResult
    retrieved_chunks: list[RetrievedChunk]
    final_answer: str
    error: str
