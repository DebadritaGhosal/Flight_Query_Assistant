from __future__ import annotations

from datetime import date, datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


class QueryIntent(str, Enum):
    FLIGHT_TRACKING = "flight_tracking"
    PASSENGER_KNOWLEDGE = "passenger_knowledge"
    CLARIFICATION = "clarification"


class FlightSubIntent(str, Enum):
    STATUS = "status"
    DELAY = "delay"
    TIMING = "timing"
    AIRPORT = "airport"
    GATE_TERMINAL = "gate_terminal"
    LOCATION = "location"
    GENERAL = "general"


class KnowledgeSubIntent(str, Enum):
    CHECK_IN = "check_in"
    BAGGAGE = "baggage"
    DISRUPTION = "disruption"
    REFUND_CANCELLATION = "refund_cancellation"
    PASSENGER_RIGHTS = "passenger_rights"
    TRAVEL_DOCUMENTS = "travel_documents"
    GENERAL = "general"


class RouteDecision(BaseModel):
    intent: QueryIntent
    sub_intent: str = "general"
    flight_number: str | None = None
    flight_date: date | None = None
    needs_clarification: bool = False
    clarification_question: str | None = None
    reasoning_summary: str = Field(
        default="",
        description="Brief non-sensitive explanation of the classification.",
    )


class AirportMovement(BaseModel):
    airport_name: str | None = None
    airport_iata: str | None = None
    airport_icao: str | None = None
    city: str | None = None
    scheduled_time_local: datetime | None = None
    revised_time_local: datetime | None = None
    actual_time_local: datetime | None = None
    scheduled_time_utc: datetime | None = None
    revised_time_utc: datetime | None = None
    actual_time_utc: datetime | None = None
    terminal: str | None = None
    gate: str | None = None


class AircraftPosition(BaseModel):
    latitude: float | None = None
    longitude: float | None = None
    altitude_meters: float | None = None
    ground_speed_kph: float | None = None
    heading_degrees: float | None = None
    updated_at_utc: datetime | None = None


class FlightStatusResult(BaseModel):
    flight_number: str
    status: str = "unknown"
    flight_date: date | None = None
    departure: AirportMovement = Field(default_factory=AirportMovement)
    arrival: AirportMovement = Field(default_factory=AirportMovement)
    departure_delay_minutes: int | None = None
    arrival_delay_minutes: int | None = None
    aircraft_model: str | None = None
    aircraft_registration: str | None = None
    position: AircraftPosition | None = None
    data_source: str = "AeroDataBox"
    raw_status: str | None = None
    warnings: list[str] = Field(default_factory=list)


class RetrievedChunk(BaseModel):
    text: str
    source: str
    page: int | None = None
    score: float | None = None


class AssistantResponse(BaseModel):
    answer: str
    intent: QueryIntent | None = None
    route: RouteDecision | None = None
    flight: FlightStatusResult | None = None
    sources: list[RetrievedChunk] = Field(default_factory=list)
    debug: dict[str, Any] = Field(default_factory=dict)


GraphRoute = Literal["flight_tracking", "passenger_knowledge", "clarification"]
