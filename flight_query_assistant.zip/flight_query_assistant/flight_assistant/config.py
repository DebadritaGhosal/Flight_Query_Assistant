from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application configuration loaded from environment variables or .env."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    openrouter_api_key: str = ""
    openrouter_model: str = "openai/gpt-4.1-mini"
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    openrouter_app_name: str = "Flight Query Assistant"
    openrouter_site_url: str = "http://localhost:8501"

    aerodatabox_api_key: str = ""
    aerodatabox_base_url: str = "https://api.aerodatabox.com"
    use_mock_flight_api: bool = True

    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    chroma_directory: Path = Path("data/chroma_db")
    knowledge_directory: Path = Path("data/knowledge")
    rag_top_k: int = Field(default=4, ge=1, le=10)
    chunk_size: int = Field(default=900, ge=200)
    chunk_overlap: int = Field(default=150, ge=0)

    default_timezone: str = "Asia/Kolkata"
    request_timeout_seconds: float = Field(default=30.0, gt=0)

    def validate_runtime(self) -> list[str]:
        warnings: list[str] = []
        if not self.openrouter_api_key:
            warnings.append("OPENROUTER_API_KEY is missing; LLM routing and RAG answers will not work.")
        if not self.use_mock_flight_api and not self.aerodatabox_api_key:
            warnings.append("AERODATABOX_API_KEY is missing while mock mode is disabled.")
        return warnings


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
