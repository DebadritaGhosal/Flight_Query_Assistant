from __future__ import annotations

from flight_assistant.clients.openrouter import OpenRouterClient
from flight_assistant.models.state import AssistantState
from flight_assistant.services.rag import RAGService


RAG_SYSTEM_PROMPT = """You are the Passenger Knowledge Assistant.
Answer only from the supplied retrieved context.
The knowledge base contains general passenger guidance, not the binding policy of every airline or country.
When a rule may vary by airline, route, fare, airport, or jurisdiction, state that clearly.
If the context does not answer the question, say that the knowledge base does not contain enough information.
Do not invent exact compensation amounts, deadlines, baggage allowances, or legal rights.
Use clear, practical language. End with a short Sources section listing the supplied source labels.
"""


def make_knowledge_node(rag: RAGService, llm: OpenRouterClient):
    def knowledge_node(state: AssistantState) -> dict:
        chunks = rag.retrieve(state["user_query"])
        if not chunks:
            return {
                "retrieved_chunks": [],
                "final_answer": (
                    "The passenger-guidance knowledge base is empty. Run "
                    "`python scripts/ingest.py` and try again."
                ),
            }
        context_parts = []
        for index, chunk in enumerate(chunks, start=1):
            page = f", page {chunk.page}" if chunk.page else ""
            context_parts.append(
                f"[Source {index}: {chunk.source}{page}]\n{chunk.text}"
            )
        prompt = (
            f"User question: {state['user_query']}\n\nRetrieved context:\n\n"
            + "\n\n".join(context_parts)
        )
        answer = llm.complete(
            system_prompt=RAG_SYSTEM_PROMPT,
            user_prompt=prompt,
            temperature=0.1,
            max_tokens=900,
        )
        return {"retrieved_chunks": chunks, "final_answer": answer}

    return knowledge_node
