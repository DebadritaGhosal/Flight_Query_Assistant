from __future__ import annotations

from datetime import date

from flight_assistant.models.state import AssistantState
from flight_assistant.services.router import QueryRouter


def make_router_node(router: QueryRouter):
    def router_node(state: AssistantState) -> dict:
        decision = router.route(state["user_query"], date.today())
        return {"route": decision}

    return router_node
