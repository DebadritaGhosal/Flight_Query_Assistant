from __future__ import annotations

from flight_assistant.models.state import AssistantState
from flight_assistant.services.formatters import format_flight_response


def make_flight_node(flight_client):
    def flight_node(state: AssistantState) -> dict:
        route = state["route"]
        if not route.flight_number or not route.flight_date:
            return {"final_answer": "Please provide both a flight number and travel date."}
        try:
            result = flight_client.get_flight_status(route.flight_number, route.flight_date)
            return {
                "flight_result": result,
                "final_answer": format_flight_response(result, state["user_query"]),
            }
        except Exception as exc:
            return {
                "error": str(exc),
                "final_answer": f"I could not retrieve that flight right now. {exc}",
            }

    return flight_node
