from __future__ import annotations

from flight_assistant.models.state import AssistantState


def clarification_node(state: AssistantState) -> dict:
    route = state["route"]
    return {
        "final_answer": route.clarification_question
        or "Please provide a little more information so I can answer accurately."
    }
