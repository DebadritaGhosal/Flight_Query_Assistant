from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

from flight_assistant.models.schemas import AircraftPosition, AirportMovement, FlightStatusResult


class MockFlightClient:
    """Deterministic demo client that consumes no external API quota."""

    def get_flight_status(self, flight_number: str, flight_date: date) -> FlightStatusResult:
        scheduled_departure = datetime.combine(
            flight_date, datetime.min.time(), tzinfo=timezone.utc
        ).replace(hour=8, minute=30)
        revised_departure = scheduled_departure + timedelta(minutes=45)
        scheduled_arrival = scheduled_departure + timedelta(hours=2, minutes=20)
        revised_arrival = scheduled_arrival + timedelta(minutes=35)
        return FlightStatusResult(
            flight_number="".join(flight_number.upper().split()),
            status="delayed",
            raw_status="Delayed",
            flight_date=flight_date,
            departure=AirportMovement(
                airport_name="Indira Gandhi International Airport",
                airport_iata="DEL",
                city="Delhi",
                scheduled_time_utc=scheduled_departure,
                revised_time_utc=revised_departure,
                terminal="3",
                gate="28",
            ),
            arrival=AirportMovement(
                airport_name="Chhatrapati Shivaji Maharaj International Airport",
                airport_iata="BOM",
                city="Mumbai",
                scheduled_time_utc=scheduled_arrival,
                revised_time_utc=revised_arrival,
                terminal="2",
            ),
            departure_delay_minutes=45,
            arrival_delay_minutes=35,
            aircraft_model="Airbus A320",
            aircraft_registration="VT-DEMO",
            position=AircraftPosition(
                latitude=24.58,
                longitude=75.68,
                altitude_meters=9750,
                ground_speed_kph=790,
                heading_degrees=220,
                updated_at_utc=datetime.now(timezone.utc),
            ),
            data_source="Mock flight data",
            warnings=["This response uses demonstration data, not a live flight feed."],
        )
