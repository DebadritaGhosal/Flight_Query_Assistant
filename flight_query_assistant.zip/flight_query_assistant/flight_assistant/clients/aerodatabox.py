from __future__ import annotations

from datetime import date, datetime
from typing import Any
from urllib.parse import quote

import httpx

from flight_assistant.config import Settings
from flight_assistant.models.schemas import AircraftPosition, AirportMovement, FlightStatusResult


class AeroDataBoxError(RuntimeError):
    pass


class AeroDataBoxClient:
    """Direct AeroDataBox REST client with response normalization."""

    STATUS_MAP = {
        "unknown": "unknown",
        "expected": "scheduled",
        "enroute": "en_route",
        "checkin": "check_in",
        "boarding": "boarding",
        "gateclosed": "gate_closed",
        "departed": "departed",
        "delayed": "delayed",
        "approaching": "approaching",
        "arrived": "landed",
        "canceled": "cancelled",
        "cancelled": "cancelled",
        "diverted": "diverted",
        "canceleduncertain": "cancellation_uncertain",
    }

    def __init__(self, settings: Settings):
        if not settings.aerodatabox_api_key:
            raise ValueError("AERODATABOX_API_KEY is not configured.")
        self.settings = settings
        self.client = httpx.Client(
            base_url=settings.aerodatabox_base_url.rstrip("/"),
            timeout=settings.request_timeout_seconds,
            headers={
                "Accept": "application/json",
                "x-api-key": settings.aerodatabox_api_key,
            },
        )

    def get_flight_status(self, flight_number: str, flight_date: date) -> FlightStatusResult:
        normalized_number = "".join(flight_number.upper().split())
        path = f"/flights/number/{quote(normalized_number)}/{flight_date.isoformat()}"
        params = {
            "withLocation": "true",
            "withAircraftImage": "false",
            "withFlightPlan": "false",
        }
        response = self.client.get(path, params=params)
        if response.status_code == 204:
            raise AeroDataBoxError(
                f"No flight data found for {normalized_number} on {flight_date.isoformat()}."
            )
        if response.status_code in {401, 403}:
            raise AeroDataBoxError("AeroDataBox rejected the API key or subscription access.")
        if response.is_error:
            detail = response.text[:400]
            raise AeroDataBoxError(
                f"AeroDataBox request failed ({response.status_code}): {detail}"
            )
        payload = response.json()
        flights = payload if isinstance(payload, list) else [payload]
        if not flights:
            raise AeroDataBoxError("AeroDataBox returned no matching flights.")
        selected = self._select_best_match(flights, normalized_number)
        return self._normalize(selected, flight_date)

    @staticmethod
    def _select_best_match(flights: list[dict[str, Any]], requested: str) -> dict[str, Any]:
        for flight in flights:
            number = str(flight.get("number") or "").replace(" ", "").upper()
            if number == requested:
                return flight
        return flights[0]

    def _normalize(self, data: dict[str, Any], flight_date: date) -> FlightStatusResult:
        raw_status = str(data.get("status") or "Unknown")
        status_key = raw_status.replace("_", "").replace(" ", "").lower()
        departure_data = data.get("departure") or {}
        arrival_data = data.get("arrival") or {}
        warnings: list[str] = []

        position = self._parse_position(data.get("location"), data)
        departure = self._parse_movement(departure_data)
        arrival = self._parse_movement(arrival_data)

        dep_delay = self._delay_minutes(departure)
        arr_delay = self._delay_minutes(arrival)
        if not departure.gate:
            warnings.append("Departure gate is not currently available.")
        if not position:
            warnings.append("Live aircraft coordinates are not currently available.")

        aircraft = data.get("aircraft") or {}
        model = aircraft.get("model")
        if isinstance(model, dict):
            model = model.get("text") or model.get("name")

        return FlightStatusResult(
            flight_number=str(data.get("number") or "Unknown"),
            status=self.STATUS_MAP.get(status_key, status_key or "unknown"),
            raw_status=raw_status,
            flight_date=flight_date,
            departure=departure,
            arrival=arrival,
            departure_delay_minutes=dep_delay,
            arrival_delay_minutes=arr_delay,
            aircraft_model=model,
            aircraft_registration=aircraft.get("reg") or aircraft.get("registration"),
            position=position,
            warnings=warnings,
        )

    def _parse_movement(self, movement: dict[str, Any]) -> AirportMovement:
        airport = movement.get("airport") or {}
        scheduled = movement.get("scheduledTime") or {}
        revised = movement.get("revisedTime") or {}
        actual = movement.get("actualTime") or {}
        return AirportMovement(
            airport_name=airport.get("name"),
            airport_iata=airport.get("iata"),
            airport_icao=airport.get("icao"),
            city=airport.get("municipalityName") or airport.get("shortName"),
            scheduled_time_local=self._dt(scheduled.get("local")),
            revised_time_local=self._dt(revised.get("local")),
            actual_time_local=self._dt(actual.get("local")),
            scheduled_time_utc=self._dt(scheduled.get("utc")),
            revised_time_utc=self._dt(revised.get("utc")),
            actual_time_utc=self._dt(actual.get("utc")),
            terminal=movement.get("terminal"),
            gate=movement.get("gate"),
        )

    @staticmethod
    def _parse_position(location: Any, root: dict[str, Any]) -> AircraftPosition | None:
        if not isinstance(location, dict):
            location = root.get("greatCircleDistance") if isinstance(root.get("greatCircleDistance"), dict) else None
        if not isinstance(location, dict):
            return None
        lat = location.get("lat") or location.get("latitude")
        lon = location.get("lon") or location.get("longitude")
        if lat is None or lon is None:
            return None
        altitude = location.get("altitude")
        speed = location.get("groundSpeed")
        track = location.get("trueTrack")
        return AircraftPosition(
            latitude=float(lat),
            longitude=float(lon),
            altitude_meters=(altitude.get("meter") if isinstance(altitude, dict) else altitude),
            ground_speed_kph=(speed.get("kmPerHour") if isinstance(speed, dict) else speed),
            heading_degrees=(track.get("deg") if isinstance(track, dict) else track),
            updated_at_utc=AeroDataBoxClient._dt(
                location.get("reportedAtUtc") or root.get("lastUpdatedUtc")
            ),
        )

    @staticmethod
    def _delay_minutes(movement: AirportMovement) -> int | None:
        scheduled = movement.scheduled_time_utc or movement.scheduled_time_local
        comparison = (
            movement.actual_time_utc
            or movement.revised_time_utc
            or movement.actual_time_local
            or movement.revised_time_local
        )
        if not scheduled or not comparison:
            return None
        return max(0, round((comparison - scheduled).total_seconds() / 60))

    @staticmethod
    def _dt(value: Any) -> datetime | None:
        if not value or not isinstance(value, str):
            return None
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
