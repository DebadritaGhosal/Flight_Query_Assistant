from __future__ import annotations

import json
import re
from typing import TypeVar

from openai import OpenAI
from pydantic import BaseModel, ValidationError

from flight_assistant.config import Settings

T = TypeVar("T", bound=BaseModel)


class OpenRouterClient:
    """Thin, model-agnostic OpenRouter client built on the OpenAI-compatible API."""

    def __init__(self, settings: Settings):
        if not settings.openrouter_api_key:
            raise ValueError("OPENROUTER_API_KEY is not configured.")
        self.settings = settings
        self.client = OpenAI(
            base_url=settings.openrouter_base_url,
            api_key=settings.openrouter_api_key,
            timeout=settings.request_timeout_seconds,
            default_headers={
                "HTTP-Referer": settings.openrouter_site_url,
                "X-OpenRouter-Title": settings.openrouter_app_name,
            },
        )

    def complete(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1,
        max_tokens: int = 900,
    ) -> str:
        response = self.client.chat.completions.create(
            model=self.settings.openrouter_model,
            temperature=temperature,
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
        )
        content = response.choices[0].message.content
        if not content:
            raise RuntimeError("OpenRouter returned an empty response.")
        return content.strip()

    def complete_json(
        self,
        *,
        system_prompt: str,
        user_prompt: str,
        schema: type[T],
        temperature: float = 0.0,
    ) -> T:
        schema_json = json.dumps(schema.model_json_schema(), indent=2)
        prompt = (
            f"{user_prompt}\n\nReturn ONLY valid JSON matching this JSON Schema:\n{schema_json}"
        )
        text = self.complete(
            system_prompt=system_prompt,
            user_prompt=prompt,
            temperature=temperature,
            max_tokens=700,
        )
        payload = self._extract_json(text)
        try:
            return schema.model_validate(payload)
        except ValidationError as exc:
            raise RuntimeError(f"LLM returned invalid structured output: {exc}") from exc

    @staticmethod
    def _extract_json(text: str) -> dict:
        cleaned = text.strip()
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
            cleaned = re.sub(r"\s*```$", "", cleaned)
        try:
            value = json.loads(cleaned)
        except json.JSONDecodeError:
            match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
            if not match:
                raise RuntimeError("No JSON object found in LLM response.")
            value = json.loads(match.group(0))
        if not isinstance(value, dict):
            raise RuntimeError("Expected a JSON object from the LLM.")
        return value
