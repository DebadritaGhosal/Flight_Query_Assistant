from __future__ import annotations

from langgraph.graph import END, START, StateGraph

from flight_assistant.clients.aerodatabox import AeroDataBoxClient
from flight_assistant.clients.mock_flight import MockFlightClient
from flight_assistant.clients.openrouter import OpenRouterClient
from flight_assistant.config import Settings
from flight_assistant.models.schemas import QueryIntent
from flight_assistant.models.state import AssistantState
from flight_assistant.nodes.clarification_node import clarification_node
from flight_assistant.nodes.flight_node import make_flight_node
from flight_assistant.nodes.knowledge_node import make_knowledge_node
from flight_assistant.nodes.router_node import make_router_node
from flight_assistant.services.rag import RAGService
from flight_assistant.services.router import QueryRouter


def build_graph(settings: Settings):
    llm = OpenRouterClient(settings)
    router = QueryRouter(llm)
    rag = RAGService(settings)
    flight_client = MockFlightClient() if settings.use_mock_flight_api else AeroDataBoxClient(settings)

    graph = StateGraph(AssistantState)
    graph.add_node("router", make_router_node(router))
    graph.add_node("flight_tracking", make_flight_node(flight_client))
    graph.add_node("passenger_knowledge", make_knowledge_node(rag, llm))
    graph.add_node("clarification", clarification_node)

    graph.add_edge(START, "router")

    def choose_route(state: AssistantState) -> str:
        intent = state["route"].intent
        if intent == QueryIntent.FLIGHT_TRACKING:
            return "flight_tracking"
        if intent == QueryIntent.PASSENGER_KNOWLEDGE:
            return "passenger_knowledge"
        return "clarification"

    graph.add_conditional_edges(
        "router",
        choose_route,
        {
            "flight_tracking": "flight_tracking",
            "passenger_knowledge": "passenger_knowledge",
            "clarification": "clarification",
        },
    )
    graph.add_edge("flight_tracking", END)
    graph.add_edge("passenger_knowledge", END)
    graph.add_edge("clarification", END)
    return graph.compile()
