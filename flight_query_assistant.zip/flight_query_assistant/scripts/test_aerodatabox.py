from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flight_assistant.clients.aerodatabox import AeroDataBoxClient
from flight_assistant.config import get_settings


def main() -> None:
    parser = argparse.ArgumentParser(description="Test a direct AeroDataBox flight lookup.")
    parser.add_argument("flight_number", help="Example: AI302")
    parser.add_argument("flight_date", help="YYYY-MM-DD")
    args = parser.parse_args()
    client = AeroDataBoxClient(get_settings())
    result = client.get_flight_status(args.flight_number, date.fromisoformat(args.flight_date))
    print(json.dumps(result.model_dump(mode="json"), indent=2))


if __name__ == "__main__":
    main()
