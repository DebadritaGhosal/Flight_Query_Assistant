from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flight_assistant.config import get_settings
from flight_assistant.services.rag import RAGService


def main() -> None:
    parser = argparse.ArgumentParser(description="Index passenger-guidance documents into Chroma.")
    parser.add_argument("--reset", action="store_true", help="Delete and rebuild the collection.")
    args = parser.parse_args()
    service = RAGService(get_settings())
    count = service.ingest_directory(reset=args.reset)
    print(f"Indexed {count} chunks.")


if __name__ == "__main__":
    main()
