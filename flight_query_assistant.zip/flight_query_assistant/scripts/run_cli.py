from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flight_assistant.config import get_settings
from flight_assistant.services.assistant import FlightQueryAssistant


def main() -> None:
    assistant = FlightQueryAssistant(get_settings())
    print("Flight Query Assistant. Type 'exit' to stop.")
    while True:
        query = input("\nYou: ").strip()
        if query.lower() in {"exit", "quit"}:
            break
        try:
            print("\nAssistant:", assistant.ask(query).answer)
        except Exception as exc:
            print("\nError:", exc)


if __name__ == "__main__":
    main()
