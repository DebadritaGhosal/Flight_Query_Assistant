from datetime import date

from flight_assistant.clients.mock_flight import MockFlightClient


def test_mock_flight_has_normalized_fields():
    result = MockFlightClient().get_flight_status("AI 302", date(2026, 7, 29))
    assert result.flight_number == "AI302"
    assert result.status == "delayed"
    assert result.departure_delay_minutes == 45
    assert result.departure.airport_iata == "DEL"
