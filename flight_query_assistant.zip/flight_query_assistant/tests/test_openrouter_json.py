from flight_assistant.clients.openrouter import OpenRouterClient


def test_extract_json_from_code_fence():
    value = OpenRouterClient._extract_json('```json\n{"intent":"flight_tracking"}\n```')
    assert value["intent"] == "flight_tracking"
