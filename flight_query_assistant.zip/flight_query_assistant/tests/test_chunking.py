from pathlib import Path

from flight_assistant.config import Settings
from flight_assistant.services.rag import RAGService


def test_chunking_has_overlap(tmp_path: Path):
    settings = Settings(
        chroma_directory=tmp_path / "db",
        knowledge_directory=tmp_path / "knowledge",
        chunk_size=200,
        chunk_overlap=40,
    )
    # Avoid loading the embedding model by testing the implementation method directly.
    service = object.__new__(RAGService)
    service.settings = settings
    chunks = list(service._chunk("word " * 100))
    assert len(chunks) > 1
    assert all(chunks)
